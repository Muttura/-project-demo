from django.urls import path
from . import views

urlpatterns = [
    path('',views.home, name='home'),
    path('join/',views.join, name='join'),
    path('update/<int:pk>/', views.update, name='update'),
    #path('delete/<int:pk>/', views.delete, name='delete'),
    #path('order_update/',views.order, name='order_update'),
]
